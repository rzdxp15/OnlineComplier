package org.olexec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineExecutorApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineExecutorApplication.class, args);
	}

}

